sap.ui.define([],function(){"use strict";return{getApiKey:function(){return window.GOOGLE_MAPS_API_KEY||"AIzaSyBnJ6XNmu3vQE6Uay9BX7q1HV-Qz_N5eP4"}}});
//# sourceMappingURL=Config.js.map